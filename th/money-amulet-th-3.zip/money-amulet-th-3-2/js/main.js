document.addEventListener("DOMContentLoaded", function () {
  $(document).on("click", 'a[href^="#"]', function (event) {
    event.preventDefault();

    $("html, body").animate(
      {
        scrollTop: $($.attr(this, "href")).offset().top,
      },
      700
    );
  });

  let isOpera =
    (!!window.opr && !!opr.addons) ||
    !!window.opera ||
    navigator.userAgent.indexOf(" OPR/") >= 0;

  if (isOpera) {
    let button = document.querySelector(".main-button");

    button.classList.add("opera-fix");
  }
});
