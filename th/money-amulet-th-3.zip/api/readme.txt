Для передачи лидов через API необходимо установить в тег <form> в атрибут action значение order.php
в результате должна получится такая строка <form action="order.php" method="POST">
файл order.php должен размещаться в одной папке с index.html